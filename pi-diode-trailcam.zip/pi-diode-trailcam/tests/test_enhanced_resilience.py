#!/usr/bin/env python3
# File: tests/test_enhanced_resilience.py
# Description: Automated Test Suite for Anti-Replay, Out-of-Order Reassembly,
#              Carousel Pass-2 Repair & Identical-Hash Nonce Isolation
# License: MIT
import sys
import os
import time
import json
import struct
import shutil
import tempfile
import hashlib
import secrets
from nacl.signing import SigningKey

# Import receiver components directly
os.environ.setdefault("ALLOW_EXAMPLE_KEYS", "1")
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../collector_hub")))
import receiver_hub

def run_resilience_test_suite():
    print("=" * 65)
    print("PI-DIODE TRAILCAM ENHANCED RESILIENCE & SECURITY TEST SUITE")
    print("=" * 65)

    # Use isolated temporary directory so tests never pollute verified_alerts/
    tmp_out_dir = tempfile.mkdtemp(prefix="trailcam_resilience_test_")
    orig_out_dir = receiver_hub.OUT_DIR
    receiver_hub.OUT_DIR = tmp_out_dir

    try:
        test_passed = 0
        total_tests = 8

        # Keys setup
        priv_hex = "9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60"
        signer = SigningKey(bytes.fromhex(priv_hex))
        node_id = "NODE-NORTH-01"

        # ----------------------------------------------------------------------
        # Test 1: Anti-Replay Protection (Duplicate Nonce, Empty Nonce & Drift)
        # ----------------------------------------------------------------------
        print("[*] 1. Testing Anti-Replay & Nonce Validation...")
        now = time.time()
        nonce1 = secrets.token_hex(8)

        valid1 = receiver_hub.is_valid_fresh_packet(node_id, int(now), nonce1)
        valid_dup = receiver_hub.is_valid_fresh_packet(node_id, int(now), nonce1)
        valid_old = receiver_hub.is_valid_fresh_packet(node_id, int(now - 400), secrets.token_hex(8))
        valid_empty = receiver_hub.is_valid_fresh_packet(node_id, int(now), "")

        assert valid1 is True, "Valid fresh packet was incorrectly rejected"
        assert valid_dup is False, "Duplicate nonce was not rejected"
        assert valid_old is False, "Expired timestamp was not rejected"
        assert valid_empty is False, "Empty nonce was not rejected"
        print("    [+] Anti-Replay Logic: PASSED (Duplicate, empty, and stale nonces rejected)")
        test_passed += 1

        # ----------------------------------------------------------------------
        # Test 2: Out-of-Order Packet Reassembly (Chunks Arriving BEFORE Metadata)
        # ----------------------------------------------------------------------
        print("[*] 2. Testing Asymmetric Reassembly (Chunks BEFORE Metadata)...")
        fake_img = b"JPEG_SIMULATED_TEST_PAYLOAD_" * 40  # ~1120 bytes (2 chunks)
        img_hash = hashlib.sha256(fake_img).hexdigest()
        nonce2 = secrets.token_hex(8)
        prefix = nonce2

        CHUNK_SIZE = 1024
        chunks = [fake_img[i:i + CHUNK_SIZE] for i in range(0, len(fake_img), CHUNK_SIZE)]
        total_chunks = len(chunks)

        receiver_hub.pending_chunks[prefix] = {
            "chunks": {},
            "total": total_chunks,
            "created_at": time.time()
        }
        for idx, c in enumerate(chunks):
            receiver_hub.pending_chunks[prefix]["chunks"][idx] = c

        assert prefix in receiver_hub.pending_chunks, "Chunk store should exist"

        meta_payload = {
            "node": node_id,
            "ts": int(time.time()),
            "pico_trig": "TRIG,MAG=3200,SEIS=400",
            "detections": [{"class": "person", "conf": 0.92}],
            "img_sha256": img_hash,
            "img_size": len(fake_img),
            "nonce": nonce2
        }
        receiver_hub.pending_meta[prefix] = {"meta": meta_payload, "created_at": time.time()}

        reconstructed = receiver_hub.try_reconstruct_image(prefix)
        assert reconstructed is True, "Failed to reconstruct image when metadata arrived after chunks!"
        assert prefix not in receiver_hub.pending_chunks, "Buffers should be freed after successful reconstruction"
        print("    [+] Out-of-Order Reassembly: PASSED (Bidirectional trigger verified)")
        test_passed += 1

        # ----------------------------------------------------------------------
        # Test 3: Stale Buffer Garbage Collection & MAX_PENDING_FRAMES Cap
        # ----------------------------------------------------------------------
        print("[*] 3. Testing Sliding-Window Garbage Collection & Queue Cap...")
        stale_prefix = "deadbeefdeadbeef"
        receiver_hub.pending_chunks[stale_prefix] = {
            "chunks": {0: b"partial"},
            "total": 5,
            "created_at": time.time() - 25.0
        }
        receiver_hub.pending_meta[stale_prefix] = {
            "meta": {"img_sha256": "deadbeef..."},
            "created_at": time.time() - 25.0
        }

        receiver_hub.cleanup_stale_buffers()
        assert stale_prefix not in receiver_hub.pending_chunks, "Stale incomplete chunks were not cleaned up!"
        assert stale_prefix not in receiver_hub.pending_meta, "Stale metadata was not cleaned up!"
        print("    [+] Memory Leak Garbage Collection: PASSED (Orphaned partial frames purged)")
        test_passed += 1

        # ----------------------------------------------------------------------
        # Test 4: End-to-End Cryptographic Packet Sign & Verify Roundtrip
        # ----------------------------------------------------------------------
        print("[*] 4. Testing End-to-End Ed25519 Packet Roundtrip with Pacing Nonce...")
        meta_json = json.dumps(meta_payload, separators=(",", ":")).encode("utf-8")
        sig = signer.sign(meta_json).signature
        pkt = b"DD\x01" + sig + meta_json

        parsed_sig = pkt[3:67]
        parsed_bytes = pkt[67:]
        receiver_hub.KNOWN_NODE_PUBKEYS[node_id].verify(parsed_bytes, parsed_sig)
        print("    [+] Cryptographic Verification: PASSED (Strict 64-byte Ed25519 match)")
        test_passed += 1

        # ----------------------------------------------------------------------
        # Test 5: Pass-1 Corrupted Chunk Repaired by Pass-2 Carousel Retransmission
        # ----------------------------------------------------------------------
        print("[*] 5. Testing Carousel Pass-2 Repair After Pass-1 Chunk Bit-Flip...")
        repair_img = b"CAROUSEL_REPAIR_TEST_IMAGE_BYTES_" * 45  # 2 chunks
        repair_hash = hashlib.sha256(repair_img).hexdigest()
        repair_nonce = secrets.token_hex(8)
        repair_nonce_bytes = bytes.fromhex(repair_nonce)
        repair_chunks = [repair_img[i:i + CHUNK_SIZE] for i in range(0, len(repair_img), CHUNK_SIZE)]

        repair_meta = {
            "node": node_id,
            "ts": int(time.time()),
            "pico_trig": "TRIG,MAG=4100,SEIS=510",
            "detections": [{"class": "car", "conf": 0.91}],
            "img_sha256": repair_hash,
            "img_size": len(repair_img),
            "nonce": repair_nonce
        }
        repair_meta_bytes = json.dumps(repair_meta, separators=(",", ":")).encode("utf-8")
        repair_hdr_pkt = b"DD\x01" + signer.sign(repair_meta_bytes).signature + repair_meta_bytes

        # Pass 1: Send valid header + corrupted chunk 0 + valid chunk 1
        receiver_hub.process_datagram(repair_hdr_pkt)
        corrupted_chunk_0 = b"CORRUPTED_BITS!" + repair_chunks[0][15:]
        pkt_c0_bad = b"DD\x02" + repair_nonce_bytes + struct.pack(">HH", 0, len(repair_chunks)) + corrupted_chunk_0
        pkt_c1_good = b"DD\x02" + repair_nonce_bytes + struct.pack(">HH", 1, len(repair_chunks)) + repair_chunks[1]
        assert receiver_hub.process_datagram(pkt_c0_bad) is False
        assert receiver_hub.process_datagram(pkt_c1_good) is False, "Corrupted Pass-1 should fail SHA-256"
        assert repair_nonce in receiver_hub.pending_meta, "Metadata must be retained for Pass-2 repair!"
        assert repair_nonce not in receiver_hub.completed_prefixes, "Corrupted burst must not be marked completed!"

        # Pass 2: Retransmit clean chunks -> should reconstruct and verify 100%
        pkt_c0_good = b"DD\x02" + repair_nonce_bytes + struct.pack(">HH", 0, len(repair_chunks)) + repair_chunks[0]
        assert receiver_hub.process_datagram(pkt_c0_good) is False
        assert receiver_hub.process_datagram(pkt_c1_good) is True, "Pass-2 clean chunks failed to repair frame!"
        print("    [+] Carousel Pass-2 Fault Repair: PASSED (Corrupted Pass-1 recovered on Pass-2)")
        test_passed += 1

        # ----------------------------------------------------------------------
        # Test 6: Consecutive Identical-Hash Images with Distinct Nonces
        # ----------------------------------------------------------------------
        print("[*] 6. Testing Consecutive Identical-Hash Frames with Distinct Nonces...")
        shared_img = b"SYNTHETIC_FALLBACK_IDENTICAL_FRAME_" * 35
        shared_hash = hashlib.sha256(shared_img).hexdigest()
        shared_chunks = [shared_img[i:i + CHUNK_SIZE] for i in range(0, len(shared_img), CHUNK_SIZE)]

        for burst_idx in (1, 2):
            b_nonce = secrets.token_hex(8)
            b_nonce_bytes = bytes.fromhex(b_nonce)
            b_meta = {
                "node": node_id,
                "ts": int(time.time()),
                "pico_trig": f"TRIG,BURST={burst_idx}",
                "detections": [],
                "img_sha256": shared_hash,
                "img_size": len(shared_img),
                "nonce": b_nonce
            }
            b_meta_bytes = json.dumps(b_meta, separators=(",", ":")).encode("utf-8")
            b_hdr = b"DD\x01" + signer.sign(b_meta_bytes).signature + b_meta_bytes
            receiver_hub.process_datagram(b_hdr)
            reconstructed_ok = False
            for idx, ch in enumerate(shared_chunks):
                cpkt = b"DD\x02" + b_nonce_bytes + struct.pack(">HH", idx, len(shared_chunks)) + ch
                if receiver_hub.process_datagram(cpkt):
                    reconstructed_ok = True
            assert reconstructed_ok is True, f"Identical-hash burst #{burst_idx} was dropped!"
        print("    [+] Identical-Hash Nonce Isolation: PASSED (Consecutive identical frames preserved)")
        test_passed += 1

        # ----------------------------------------------------------------------
        # Test 7: 2 km NLOS Sub-GHz FHSS/LoRa Relay Bridge & Dead-Drop Export
        # ----------------------------------------------------------------------
        print("[*] 7. Testing 2 km NLOS Sub-GHz FHSS/LoRa Relay & Dead-Drop Vault Retention...")
        from subghz_nlos_relay import build_nlos_serial_frames, parse_nlos_serial_stream

        nlos_nonce = secrets.token_hex(8)
        nlos_alert = {
            "node": node_id,
            "ts": int(time.time()),
            "nonce": nlos_nonce,
            "detections": [{"class": "person", "conf": 0.95}],
            "pico_trig": "TRIG,MAG=120,SEIS=410,RADAR_M=5.1",
        }
        serial_frames, _, _ = build_nlos_serial_frames(nlos_alert, shared_img, priv_hex)
        # Inject random RF channel noise between serial frames and drop 1 frame from Pass 1 (repaired by Pass 2)
        pass1_noisy = b"\xff\x00NOISE" + b"\xaa\x55".join(serial_frames[:-1]) + b"GARBAGE"
        pass2_clean = b"".join(serial_frames)
        extracted_dd_pkts = parse_nlos_serial_stream(pass1_noisy + pass2_clean)
        nlos_reconstructed = False
        for pkt in extracted_dd_pkts:
            if receiver_hub.process_datagram(pkt):
                nlos_reconstructed = True
        assert nlos_reconstructed is True, "2 km NLOS Sub-GHz relay stream failed to reconstruct at Farmhouse hub!"

        # Verify Dead-Drop Vault export bundle and circular retention
        bundle_zip = os.path.join(tmp_out_dir, "courier_export.zip")
        exported_count = receiver_hub.export_dead_drop_bundle(bundle_zip, out_dir=tmp_out_dir)
        assert exported_count >= 4 and os.path.isfile(bundle_zip)
        removed_count = receiver_hub.enforce_storage_retention(out_dir=tmp_out_dir, max_files=2)
        assert removed_count >= 1
        print("    [+] 2 km NLOS Sub-GHz Relay & Dead-Drop Vault Retention: PASSED")
        test_passed += 1

        # ----------------------------------------------------------------------
        # Test 8: Real-World Photo Build Sheets (Photos 1–58), Hole-by-Hole Pin Map & PDF Integrity
        # ----------------------------------------------------------------------
        print("[*] 8. Testing Real-World Photo Build Sheets (Photos 1–58), Hole Map & PDF Booklet...")
        pkg_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        repo_root = os.path.dirname(pkg_root)
        docs_dir = os.path.join(pkg_root, "docs")
        imgs_dir = os.path.join(docs_dir, "images")
        required_images = [
            "real_build/stage1_real_world_cooler_part1_heatsink.jpg",
            "real_build/stage1_real_world_cooler_part2_fan_plug.jpg",
            "real_build/stage1_real_world_pico2_usb_setup.jpg",
            "real_build/stage2_real_world_pico2_on_breadboard.jpg",
            "real_build/stage2_real_world_sd_and_usb_prep.jpg",
            "real_build/stage2_real_world_jumpers_part1.jpg",
            "real_build/stage2_real_world_gy271_compass_part2a.jpg",
            "real_build/stage2_real_world_pi5_gpio_part2b.jpg",
            "real_build/stage2_real_world_camera_ribbon_part3a.jpg",
            "real_build/stage2_real_world_pin_check_and_golden_part3b.jpg",
            "real_build/compass_5pin_vs_4wires_1hole_shift_fix_v2.jpg",
            "real_build/ribbon_both_sides_and_j4_slot_guide_v1.jpg",
            "real_build/stage2_4b_verified_and_step2_5_usb_power_guide_v1.jpg",
            "device_1_camera_radar_pod.jpg",
            "device_2_base_compute_vault.jpg",
            "device_3_collector_units.jpg",
            "product_units_in_context.jpg",
            "deployment_scenarios_cabin_vs_remote.jpg",
        ]
        for img_name in required_images:
            img_path = os.path.join(imgs_dir, img_name)
            assert os.path.isfile(img_path) and os.path.getsize(img_path) > 50000, f"Missing or empty diagram: {img_name}"

        pdf_path = os.path.join(repo_root, "ARCTIC_TRAIL_CAM_BUILD_AND_FIELD_GUIDE.pdf")
        assert os.path.isfile(pdf_path) and os.path.getsize(pdf_path) > 1000000, "Printable PDF booklet missing or incomplete"

        required_holes = ["Hole j5", "Hole f24", "Hole j3", "Hole f25", "Hole a6", "Hole f27", "Hole a7", "Hole f26", "Hole a11", "Hole a4", "Hole a13"]
        for doc_file in (
            os.path.join(docs_dir, "WIRING_PINOUT.md"),
            os.path.join(docs_dir, "BENCHTOP_QUICKSTART_GUIDE.md"),
            os.path.join(pkg_root, "run_guided_bench_doctor.py"),
        ):
            with open(doc_file, "r", encoding="utf-8") as df:
                content = df.read()
            for hole in required_holes:
                assert hole in content, f"Missing exact breadboard coordinate '{hole}' in {os.path.basename(doc_file)}"

        # Verify macOS anti-metadata protection is built into run_guided_bench_doctor.py
        with open(os.path.join(pkg_root, "run_guided_bench_doctor.py"), "r", encoding="utf-8") as bf:
            bcontent = bf.read()
        assert 'os.environ["COPYFILE_DISABLE"] = "1"' in bcontent
        assert "purge_macos_metadata" in bcontent

        # Verify Boot-Order & Power-Glitch Optical Diode Hardening (RP1 GPIO 32 ETH_RST_N + IPv6 ff02::1 multicast)
        from unittest.mock import patch, MagicMock
        sys.path.insert(0, os.path.join(pkg_root, "pi5_sender_node"))
        import sender_node
        assert hasattr(sender_node, "renegotiate_optical_diode_link"), "Missing renegotiate_optical_diode_link in sender_node"
        assert hasattr(receiver_hub, "_join_ipv6_all_nodes_multicast"), "Missing _join_ipv6_all_nodes_multicast in receiver_hub"
        with patch.object(sender_node.subprocess, "run") as mock_sub_run, patch.object(sender_node, "wait_for_ethernet_carrier", return_value=True):
            mock_sub_run.return_value = MagicMock(returncode=0)
            retrig_ok = sender_node.renegotiate_optical_diode_link(iface="eth0", force_phy_reset=True, down_hold_s=0.1)
            assert retrig_ok is True
            called_cmds = [c.args[0] for c in mock_sub_run.call_args_list if c.args]
            assert ["pinctrl", "set", "32", "op", "dl"] in called_cmds
            assert ["pinctrl", "set", "32", "op", "dh"] in called_cmds

        # Enforce permanent architectural guardrails & comments so future refactoring never removes them:
        with open(os.path.join(pkg_root, "pi5_sender_node", "sender_node.py"), "r", encoding="utf-8") as sf:
            s_code = sf.read()
        assert "CRITICAL ARCHITECTURAL INVARIANTS (DO NOT REMOVE OR BREAK DURING REFACTORING)" in s_code
        assert 'os.environ.setdefault("OMP_NUM_THREADS", "1")' in s_code
        assert "cv2.setNumThreads(1)" in s_code

        with open(os.path.join(pkg_root, "collector_hub", "dashboard_server.py"), "r", encoding="utf-8") as df_srv:
            d_code = df_srv.read()
        assert "CRITICAL OPERATOR-UI TRUTHFULNESS INVARIANT" in d_code
        assert "MAX_LIVE_FRAME_AGE_SEC" in d_code

        with open(os.path.join(pkg_root, "collector_hub", "ui", "index.html"), "r", encoding="utf-8") as uf:
            u_code = uf.read()
        assert "NO LIVE CAMERA SIGNAL (OPTICAL DIODE LINK OFFLINE)" in u_code
        assert "cam-corner-delay-hud" in u_code

        assert hasattr(sender_node, "should_continue_warm_hold_loop"), "Missing should_continue_warm_hold_loop in sender_node"
        # Branch 1: Minimum warm burst frames (burst_idx=0, 1 < min_burst_frames=3 -> True)
        assert sender_node.should_continue_warm_hold_loop(
            burst_idx=0, session_elapsed_s=0.7, since_last_detection_s=None, detections_in_current_frame=0,
            min_burst_frames=3, hold_after_detection_s=12.0, max_session_s=24.0
        ) is True
        # Branch 2: No detections after min_burst_frames reached -> False (powers down cleanly)
        assert sender_node.should_continue_warm_hold_loop(
            burst_idx=2, session_elapsed_s=2.1, since_last_detection_s=None, detections_in_current_frame=0,
            min_burst_frames=3, hold_after_detection_s=12.0, max_session_s=24.0
        ) is False
        # Branch 3: Active detection or within 12.0s post-detection hold -> True (streams at ~0.6s intervals)
        assert sender_node.should_continue_warm_hold_loop(
            burst_idx=5, session_elapsed_s=4.5, since_last_detection_s=3.2, detections_in_current_frame=0,
            min_burst_frames=3, hold_after_detection_s=12.0, max_session_s=24.0
        ) is True
        # Branch 4: Hard 24.0s session ceiling before Pico 35.0s hardware watchdog -> False
        assert sender_node.should_continue_warm_hold_loop(
            burst_idx=15, session_elapsed_s=24.1, since_last_detection_s=0.1, detections_in_current_frame=2,
            min_burst_frames=3, hold_after_detection_s=12.0, max_session_s=24.0
        ) is False

        # Gap 4: AI Triage Gate & Local Black-Box Spooling
        assert sender_node.should_transmit_after_triage(
            detections_found=[], pico_telemetry="TRIG,MAG=120,SEIS=0,SPD=0,FAST_SNAP=0", suppress_empty_frames=True
        ) is False
        assert sender_node.should_transmit_after_triage(
            detections_found=[{"class": "person", "conf": 0.91}], pico_telemetry="TRIG,MAG=120", suppress_empty_frames=True
        ) is True
        assert sender_node.should_transmit_after_triage(
            detections_found=[], pico_telemetry="TRIG,MAG=120,FAST_SNAP=4096,FAST_SNAP_MS=140,FAST_SNAP_HEX=FFD8FFE0", suppress_empty_frames=True
        ) is True

        # Gap 5: Sub-2-Second Pre-Roll Snapshot Extraction
        preroll_meta = sender_node.parse_preroll_fast_snap_telemetry(
            "TRIG,MAG=120,FAST_SNAP=4096,FAST_SNAP_MS=140,FAST_SNAP_HEX=FFD8FFE000104A464946"
        )
        assert preroll_meta["preroll_captured"] is True
        assert preroll_meta["preroll_snap_ms"] == 140
        assert preroll_meta["under_2s_sensory_sla"] is True
        assert preroll_meta["preroll_header_hex"].startswith("FFD8FFE0")

        # Local Black-Box Spool Ring-Buffer Verification
        spool_test_dir = os.path.join(tmp_out_dir, "local_spool_test")
        for s_i in range(4):
            sp_path = sender_node.spool_verified_alert_locally(
                {"node": "NODE-NORTH-01", "ts": 1793200000 + s_i, "nonce": f"001122334455660{s_i}"},
                b"\xff\xd8\xff\xe0JFIF_TEST",
                spool_dir=spool_test_dir,
                max_spool_files=2,
            )
            assert sp_path is not None and os.path.exists(sp_path)
        spool_jpgs = [fn for fn in os.listdir(spool_test_dir) if fn.endswith(".jpg")]
        assert len(spool_jpgs) == 2

        # Gap 6: UX Armed Standby (0.00W Forest Sleep) vs Continuous Bench Mode
        assert "ARMED STANDBY • 0.00W FOREST SLEEP" in u_code
        assert "autonomous_standby" in d_code

        print("    [+] Real-World Photo Build Sheets (Photos 1–58), Hole Map, Boot-Order Hardening & macOS Anti-Metadata: PASSED")
        test_passed += 1

        print("=" * 65)
        print(f"[ALL {test_passed}/{total_tests} RESILIENCE TESTS PASSED CLEANLY!]")
        print("=" * 65)
    finally:
        receiver_hub.OUT_DIR = orig_out_dir
        shutil.rmtree(tmp_out_dir, ignore_errors=True)

if __name__ == "__main__":
    run_resilience_test_suite()

